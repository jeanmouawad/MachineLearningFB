import{c as o,j as s}from"./index-Cd1qZMWI.js";const a=o(s.jsx("path",{d:"M5 20h14v-2H5zm0-10h4v6h6v-6h4l-7-7z"}));export{a as U};
