import { useTranslation } from 'react-i18next';
import style from './style.module.css';
import Model from './Model';
import { useState } from 'react';
import { Checkbox, FormControlLabel } from '@mui/material';
import { theme } from '../../theme/theme';
import { ThemeProvider } from '@mui/material/styles';
import RecordVoiceOverIcon from '@mui/icons-material/RecordVoiceOver';
import Logo from '../../components/Logo/Logo';
import LogoutButton from '../../components/LogoutButton/LogoutButton';
import AppLanguageSelect from '../../components/LanguageSelect/AppLanguageSelect';

export default function Home() {
    const { t } = useTranslation('image_adv');
    const [usb, setUsb] = useState(false);

    const hasSerial = 'serial' in navigator;

    return (
        <ThemeProvider theme={theme}>
            <main className={style.homeContainer}>
                <div className={style.topBar}>
                    <AppLanguageSelect />
                    <LogoutButton color="primary" />
                </div>
                <div className={style.header}>
                    <Logo height={140} />
                    <div className={style.headerColumn}>
                        <h1>{t('app.title')}</h1>
                        <h2>{t('app.subtitle')}</h2>
                    </div>
                </div>
                <div className={style.selectGroup}>
                    <div className={style.intro}>{t('app.selectModel')}</div>
                    <div className={style.cards}>
                        <Model
                            id="image"
                            usb={usb}
                            image="/dog1.jpg"
                        />
                        <Model
                            id="pose"
                            usb={usb}
                            image="/body.jpg"
                        />
                        <Model
                            id="hand"
                            usb={usb}
                            image="/gesture1.jpg"
                        />
                        <Model
                            id="speech"
                            usb={usb}
                            image="/sound1.jpg"
                            icon={<RecordVoiceOverIcon sx={{ fontSize: 64 }} />}
                        />
                    </div>
                    {hasSerial && (
                        <div className={style.options}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={usb}
                                        name="allowSerialUSB"
                                        onChange={(e) => setUsb(e.target.checked)}
                                    />
                                }
                                label={t('app.enableUSB')}
                            />
                        </div>
                    )}
                </div>
            </main>
        </ThemeProvider>
    );
}
