import { FormEvent, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Button, IconButton, InputAdornment, TextField } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import { theme } from '../../theme/theme';
import { DEMO_ACCESS_CODE, DEMO_USERNAME } from '../../auth/config';
import { isAuthenticated, login, validateCredentials } from '../../auth/auth';
import Logo from '../../components/Logo/Logo';
import style from './style.module.css';

const fieldSx = {
    '& .MuiOutlinedInput-root': {
        borderRadius: '12px',
        background: '#ffffff',
        fontFamily: '"Source Sans 3", "Segoe UI", sans-serif',
        '& fieldset': { borderColor: '#c5d8da' },
        '&:hover fieldset': { borderColor: '#01717a' },
        '&.Mui-focused fieldset': { borderColor: '#01717a', borderWidth: '2px' },
    },
    '& .MuiInputLabel-root': {
        fontFamily: '"Source Sans 3", "Segoe UI", sans-serif',
    },
};

export default function Login() {
    const navigate = useNavigate();
    const location = useLocation();
    const from = (location.state as { from?: string } | null)?.from || '/home';
    const [username, setUsername] = useState('');
    const [accessCode, setAccessCode] = useState('');
    const [showCode, setShowCode] = useState(false);
    const [error, setError] = useState('');

    if (isAuthenticated()) {
        return (
            <Navigate
                to={from}
                replace
            />
        );
    }

    const handleSubmit = (event: FormEvent) => {
        event.preventDefault();
        setError('');

        if (!validateCredentials(username, accessCode, DEMO_USERNAME, DEMO_ACCESS_CODE)) {
            setError('Invalid username or access code. Please try again.');
            return;
        }

        login();
        navigate(from, { replace: true });
    };

    return (
        <ThemeProvider theme={theme}>
            <div className={style.loginPage}>
                <aside className={style.brandPanel}>
                    <div className={style.orbOne} aria-hidden="true" />
                    <div className={style.orbTwo} aria-hidden="true" />
                    <div className={style.brandContent}>
                        <div className={style.logoCard}>
                            <Logo height={148} />
                        </div>
                        <h1 className={style.brandTitle}>AI Teachable Machine</h1>
                        <p className={style.brandCopy}>
                            A no-code AI machine learning classroom tool. Train simple image, pose, gesture, and speech
                            classifiers in the browser — your samples stay on this device unless you choose to share
                            them.
                        </p>
                        <div className={style.partner}>
                            <span className={style.partnerLabel}>Prepared for</span>
                            <img
                                src="/unicef-logo.svg"
                                alt="UNICEF"
                                className={style.unicefLogo}
                            />
                        </div>
                    </div>
                </aside>

                <main className={style.formPanel}>
                    <div className={style.formInner}>
                        <div className={style.mobileBrand}>
                            <Logo height={72} />
                            <img
                                src="/unicef-logo.svg"
                                alt="UNICEF"
                                className={style.unicefLogoMobile}
                            />
                        </div>
                        <p className={style.formEyebrow}>Welcome back</p>
                        <h2 className={style.formTitle}>Sign in to continue</h2>
                        <p className={style.formLead}>Use the demo username and access code provided for this review.</p>

                        <form
                            className={style.form}
                            onSubmit={handleSubmit}
                            noValidate
                        >
                            <TextField
                                id="login-username"
                                label="Username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                autoComplete="username"
                                required
                                fullWidth
                                sx={fieldSx}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <PersonOutlineIcon htmlColor="#01717a" />
                                        </InputAdornment>
                                    ),
                                }}
                            />
                            <TextField
                                id="login-code"
                                label="Access code"
                                value={accessCode}
                                onChange={(e) => setAccessCode(e.target.value)}
                                type={showCode ? 'text' : 'password'}
                                autoComplete="current-password"
                                required
                                fullWidth
                                sx={fieldSx}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <LockOutlinedIcon htmlColor="#01717a" />
                                        </InputAdornment>
                                    ),
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label={showCode ? 'Hide access code' : 'Show access code'}
                                                onClick={() => setShowCode((open) => !open)}
                                                edge="end"
                                                size="large"
                                            >
                                                {showCode ? (
                                                    <VisibilityOffOutlinedIcon />
                                                ) : (
                                                    <VisibilityOutlinedIcon />
                                                )}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                            />
                            {error && (
                                <p
                                    className={style.error}
                                    role="alert"
                                >
                                    {error}
                                </p>
                            )}
                            <Button
                                type="submit"
                                variant="contained"
                                color="primary"
                                size="large"
                                fullWidth
                                className={style.submit}
                                sx={{
                                    textTransform: 'none',
                                    fontWeight: 600,
                                    fontSize: '1.05rem',
                                    py: 1.4,
                                    borderRadius: '12px',
                                    fontFamily: '"Lexend", "Segoe UI", sans-serif',
                                    boxShadow: 'none',
                                    '&:hover': {
                                        background: '#015a61',
                                        boxShadow: '0 8px 20px rgba(1, 113, 122, 0.28)',
                                    },
                                }}
                            >
                                Sign in
                            </Button>
                        </form>

                        <div className={style.hint}>
                            <span className={style.hintLabel}>Demo credentials</span>
                            <p>
                                Username <strong>{DEMO_USERNAME}</strong>
                                <span className={style.dot} aria-hidden="true">
                                    ·
                                </span>
                                Code <strong>{DEMO_ACCESS_CODE}</strong>
                            </p>
                        </div>
                    </div>
                </main>
            </div>
        </ThemeProvider>
    );
}
