export const DEMO_USERNAME = import.meta.env.VITE_DEMO_USERNAME || 'demo';
export const DEMO_ACCESS_CODE = import.meta.env.VITE_DEMO_ACCESS_CODE || 'UNICEF-DEMO';

export const AUTH_SESSION_KEY = 'tm_demo_authenticated';
